package com.proj.consumer;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Arrays;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class MainMenu extends JFrame {

	private JPanel contentPane;
	private JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu frame = new MainMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public UfData fillComboBox(JComboBox comboBox) throws JSONException, IOException {

		Consumer con = new Consumer();

		JSONArray json = con.readJsonFromUrl("https://servicodados.ibge.gov.br/api/v1/localidades/estados");

		String[] comboText = new String[json.length() + 1];
		String[] comboId = new String[json.length() + 1];
		comboText[0] = "";
		comboId[0] = "";

		for (int i = 0; i < json.length(); i++) {

			JSONObject jsonObj = json.getJSONObject(i);

			comboText[i + 1] = String.valueOf(jsonObj.get("sigla"));
			comboId[i + 1] = String.valueOf(jsonObj.get("id"));
		}

		UfData ufData = new UfData(comboText, comboId);
		return ufData;

	}

	/**
	 * Create the frame.
	 * 
	 * @throws IOException
	 * @throws JSONException
	 */

	String[] ufText, ufId;
	String comboText;

	public MainMenu() throws JSONException, IOException {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1309, 785);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblEscolhaOUf = new JLabel("Escolha a UF:");
		lblEscolhaOUf.setBounds(10, 11, 85, 14);
		contentPane.add(lblEscolhaOUf);

		final JComboBox comboBox = new JComboBox();
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				comboText = String.valueOf(comboBox.getSelectedItem());
			}
		});

		UfData ufData = fillComboBox(comboBox);

		ufText = ufData.getUfText();
		ufId = ufData.getUfId();

		comboBox.setModel(new DefaultComboBoxModel(ufText));
		comboBox.setBounds(92, 8, 65, 20);
		contentPane.add(comboBox);

		textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setBounds(0, 34, 1293, 794);
		contentPane.add(textArea);

		JButton btnNewButton = new JButton("Pesquisar Munic\u00EDpios");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText("");
				Consumer con = new Consumer();

				int index = Arrays.asList(ufText).indexOf(comboText);
				String uf = ufId[index].toString();

				String url = "https://servicodados.ibge.gov.br/api/v1/localidades/estados/" + uf + "/municipios";

				try {
					JSONArray json = con.readJsonFromUrl(url);

					for (int i = 0; i < json.length(); i++) {

						JSONObject jsonObj = json.getJSONObject(i);
						textArea.setText(textArea.getText() + String.valueOf(jsonObj.get("nome") + ";"));

					}
				} catch (JSONException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}

			// }
		});
		btnNewButton.setBounds(167, 7, 161, 23);
		contentPane.add(btnNewButton);

	}
}
