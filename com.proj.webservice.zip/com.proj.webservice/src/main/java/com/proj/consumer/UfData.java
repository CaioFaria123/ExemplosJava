package com.proj.consumer;

public class UfData {

	private String ufText[];
	private String ufId[];
	
	public UfData(String[] ufData, String[] ufId) {
		super();
		this.ufText = ufData;
		this.ufId = ufId;
	}

	public String[] getUfText() {
		return ufText;
	}

	public void setUfText(String[] ufData) {
		this.ufText = ufData;
	}

	public String[] getUfId() {
		return ufId;
	}

	public void setUfId(String[] ufId) {
		this.ufId = ufId;
	}
	
}
