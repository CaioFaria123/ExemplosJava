package com.proj.consumer;


import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;

public class Consumer {
	
	public void consume() {
		
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target("https://servicodados.ibge.gov.br/api/v1/localidades/estados");
		JSONArray response = target.request(MediaType.APPLICATION_JSON).get(JSONArray.class);
		JSONObject obj = JSONFactoryUtil.createJSONObject();
		
		for (int i = 0; i < response.length(); i++) {
			
			obj = response.getJSONObject(i);
			System.out.println(obj.getString("sigla"));
			
		}
		
		
		
	}
	
}
